<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cars and Care</title>
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
  </head>
  <body>
<!--Navbar Starts-->
<nav class="navbar navbar-expand-lg ">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php"><img src="assets/carscare-logo.png" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Service Option
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">New Cars</a></li>
              <li><a class="dropdown-item" href="#">Second Hand Cars</a></li>
              <li><a class="dropdown-item" href="#">Car Services</a> </li>
            </ul>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control rounded-0 form1 me-2" type="search" placeholder="Search Cars..." aria-label="Search">
          <button class="btn btn2 rounded-0 me-5" type="submit"><i class="fas fa-search"></i></button>
        </form>
        <a href="login.php"><button class="btn rounded-0 login me-5" type="submit">Login</button></a>
         <a href="register.php"><button class="btn rounded-0 login me-5" type="submit">Register</button></a>
         <!--<button onclick="myFunction()">Toggle dark mode</button>-->
         
      </div>
    </div>
  </nav>
<!--Navbar Ends-->

<div class="img-slider">
  <div class="slide active">
    <img src="http://jarmuipar.hu/wp-content/uploads/2017/08/laferrari_aperta_2.jpg">
    <div class="info">
      <h2>New Cars</h2>
      <p>Buy your dream car </p>
    </div>
  </div>
  <div class="slide">
    <img src="assets/vintage2.jpg">
    <div class="info">
      <h2>Second Hand Cars</h2>
      <p>Buy a less used car at best price</p>
    </div>
  </div>
  <div class="slide">
    <img src="assets/service.jpg" alt="">
    <div class="info">
      <h2>Car Service</h2>
      <p>We care for your Cars</p>
    </div>
  </div>
  <!-- <div class="navigation">
    <div class="btn active"></div>
    <div class="btn"></div>
    <div class="btn"></div>
  </div> -->
</div>


<!--Demanding Courses-->
<div class="demand">
  <h2>New Cars</h2>
</div>
<!-- Swiper -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <img src="assets/hatchback1.webp" alt="img">
      <span class="discount-tag">8% off</span>
      <div class="info1">
        <h3>ALTROZ TDI</h3>
        <p>A premium hatchback form TATA</p>
        <h5>Price: <span class="duration">8</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/sedan2.jpg" alt="img">
      <span class="discount-tag">7% off</span>
      <div class="info1">
        <h3>HONDA AMAZE</h3>
        <p>A comfortable Sedan from HONDA</p>
        <h5>Price: <span class="duration">11</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="./assets/hatchback2.webp" alt="img">
      <span class="discount-tag">10%% off</span>
      <div class="info1">
        <h3>SWIFT VXI</h3>
        <p>A premium hatchback from MARUTI</p>
        <h5>Price: <span class="duration">6</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/luxury1.jpg" alt="img">
      <span class="discount-tag">No discount</span>
      <div class="info1">
        <h3>ROLLS ROYCE</h3>
        <p>A durable Luxury from ROLLS ROYCE</p>
        <h5>Price: <span class="duration">6</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    </div>
    </div>
    
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>



<!--Programing Courses-->
<br>
<div class="demand">
  <h2>Second Hand Cars</h2>
</div>
<!-- Swiper -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <img src="assets/second1.jpg" alt="img">
      <span class="discount-tag">20% off</span>
      <div class="info1">
        <h3>AUDI R3</h3>
        <p>Buy great luxury at best price</p>
        <h5>Price: <span class="duration">16</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/second2.jpg" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Maruti WagonR</h3>
        <p>A great mileage car from Mruti</p>
        <h5>Price: <span class="duration">3</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/second3.jpg" alt="img">
      <span class="discount-tag">30% off</span>
      <div class="info1">
        <h3>Mahindra Scorpio</h3>
        <p>A less driven Suv at best condition</p>
        <h5>Price: <span class="duration">8</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/second4.png" alt="img">
      <span class="discount-tag">40% off</span>
      <div class="info1">
        <h3>Hundai i20</h3>
        <p>2018 model at best condition and price</p>
        <h5>Price: <span class="duration">5</span> Lac. </h5>
        <a href="#">Know More</a>
      </div>
    </div>
    </div>
    </div>
    
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>

<!--Footer starts-->
<footer>
  <div class="content">
    <div class="top">
      <div class="logo-details">
        <a class="navbar-brand" href="index.html"><img src="assets/carscare-logo.png" alt=""></a>
      </div>
      <div class="media-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
    <div class="link-boxes">
      <ul class="box">
        <li class="link_name">Company</li>
        <li><a href="index.html">Home</a></li>
        <li><a href="contact.php">Contact us</a></li>
        <li><a href="aboutus.html">About us</a></li>
        <li><a href="index.html">Start Purchasing</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Services</li>
        <li><a href="#">New Purchase</a></li>
        <li><a href="#">Second Hand Purchase </a></li>
        <li><a href="#">Full Car Service</a></li>
        <li><a href="#"> Car Repair</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Cars</li>
        <li><a href="#">Hatchback</a></li>
        <li><a href="#">Sedan</a></li>
        <li><a href="#">Luxury</a></li>
        <li><a href="#">Suv</a></li>
      </ul>
      <ul class="box input-box">
        <li class="link_name">Subscribe</li>
        <li><input type="text" placeholder="Enter your email"></li>
        <li><input type="button" value="Subscribe"></li>
      </ul>
    </div>
  </div>
  <hr>
  <div class="bottom-details">
    <div class="bottom_text">
      <span class="copyright_text">Copyright © 2022&nbsp;&nbsp; <a href="index.html">Cars and Care</a>All rights reserved</span>
      <span class="policy_terms">
        <a href="privacy.html">Privacy policy</a>
        <a href="terms_condition.html">Terms & condition</a>
      </span>
    </div>
  </div>
</footer>


<script type="text/javascript">
  var slides = document.querySelectorAll('.slide');
  var btns = document.querySelectorAll('.btn');
  let currentSlide = 1;
  
  // Javascript for image slider manual navigation
  var manualNav = function(manual){
    slides.forEach((slide) => {
      slide.classList.remove('active');
  
      btns.forEach((btn) => {
        btn.classList.remove('active');
      });
    });
  
    slides[manual].classList.add('active');
    btns[manual].classList.add('active');
  }
  
  btns.forEach((btn, i) => {
    btn.addEventListener("click", () => {
      manualNav(i);
      currentSlide = i;
    });
  });
  
  // Javascript for image slider autoplay navigation
  var repeat = function(activeClass){
    let active = document.getElementsByClassName('active');
    let i = 1;
  
    var repeater = () => {
      setTimeout(function(){
        [...active].forEach((activeSlide) => {
          activeSlide.classList.remove('active');
        });
  
      slides[i].classList.add('active');
      btns[i].classList.add('active');
      i++;
  
      if(slides.length == i){
        i = 0;
      }
      if(i >= slides.length){
        return;
      }
      repeater();
    }, 10000);
    }
    repeater();
  }
  repeat();
  </script>
  <!-- Swiper JS -->
  <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

  <script>
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 'auto',
      spaceBetween: 40,
      centeredSlides: true,
      grabCursor: true,
      loop: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>

  <script src="asset/js/script.js"></script>
  </body>
</html>
