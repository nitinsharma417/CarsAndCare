<?php
	$link = mysqli_connect("localhost", "root", "", "carcare");
 
		// Check connection
		if($link === false){
		    die("ERROR: Could not connect. " . mysqli_connect_error());
		}
	if($_SERVER["REQUEST_METHOD"] == "POST") {

	$name = $_POST["name"];
	$email = $_POST["email"];
	$mobile = $_POST["mobile"];
	$city = $_POST["city"];
	$car = $_POST["car"];
	$description = $_POST["description"];
}

	$sql = "INSERT INTO contactusquery ( name, email, mobile,	city,	car,	description) VALUES ('$name' ,'$email','$mobile','$city','$car','$description')";
	// $sql = "INSERT INTO users (name, email, mobile, password) VALUES ('$name','$email','$mobile','$password')";
	if(mysqli_query($link, $sql)){
    echo '<script>alert("Thanks query Submitted")</script>';

	} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	header('Location: index.php');
	}
 
mysqli_close($link);
?>
